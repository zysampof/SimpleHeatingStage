#include "stm32f10x.h"                  // Device header
#include "AD.h"
#include "MATH.h"

#define	AD_MAX		4096
#define R_Ref_K		10//参考电阻的阻值为10欧

/**
  * 函    数：NTC初始化
  * 参    数：无
  * 返 回 值：无
  */
void NTC_Init(void)
{
	AD_Init();
}

/**
  * 函    数：NTC读取
  * 参    数：无
  * 返 回 值：无
  * 注意事项：无
  */
uint16_t NTC_GetData(void)
{
	uint16_t AD_Read;
	uint16_t R_NTC;
	
	AD_Read = AD_GetValue();
	
	R_NTC = (R_Ref_K * AD_Read) / (AD_MAX - AD_Read);
	
	return R_NTC;
}
//那可真是太开心了呢 https://blog.csdn.net/qq_44708426/article/details/107159424?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522170719917616800180622736%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=170719917616800180622736&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~baidu_landing_v2~default-11-107159424-null-null.142^v99^pc_search_result_base4&utm_term=NTC&spm=1018.2226.3001.4187










