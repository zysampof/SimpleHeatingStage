#ifndef __NTC_H__
#define __NTC_H__



void NTC_Init(void);
uint16_t NTC_GetData(void);





#endif
